package com.bscan.app.feature.importmedia

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bscan.app.core.data.preferences.PreferencesStore
import com.bscan.app.core.data.repository.ProjectRepository
import com.bscan.app.core.data.storage.SampledBitmapLoader
import com.bscan.app.core.model.PreviewResolutionCap
import com.bscan.app.core.model.ScanProject
import com.bscan.app.processing.ocr.TesseractOcrEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ImportedPreviewUiState(
    val project: ScanProject? = null,
    val selectedPageIndex: Int = 0,
    val previewMaxEdgePx: Int = PreviewResolutionCap.BALANCED.maxLongEdgePx,
    val isLoading: Boolean = true,
    val isAddingPages: Boolean = false,
    val isRecognizingText: Boolean = false,
    val recognizedText: String? = null,
    val ocrConfidence: Int? = null,
    val ocrErrorMessage: String? = null,
    val errorMessage: String? = null,
)

class ImportedPreviewViewModel(
    private val projectId: String,
    private val projectRepository: ProjectRepository,
    preferencesStore: PreferencesStore,
    private val bitmapLoader: SampledBitmapLoader,
    private val ocrEngine: TesseractOcrEngine,
) : ViewModel() {

    private val selectedPageIndex = MutableStateFlow(0)
    private val isAddingPages = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)
    private val isRecognizingText = MutableStateFlow(false)
    private val recognizedText = MutableStateFlow<String?>(null)
    private val ocrConfidence = MutableStateFlow<Int?>(null)
    private val ocrErrorMessage = MutableStateFlow<String?>(null)

    private val baseUiState = combine(
        projectRepository.observeProject(projectId),
        selectedPageIndex,
        preferencesStore.preferences,
        isAddingPages,
        errorMessage,
    ) { project, pageIdx, prefs, adding, error ->
        val safeIndex = if (project == null || project.pages.isEmpty()) {
            0
        } else {
            pageIdx.coerceIn(0, project.pages.lastIndex)
        }
        ImportedPreviewUiState(
            project = project,
            selectedPageIndex = safeIndex,
            previewMaxEdgePx = prefs.previewResolutionCap.maxLongEdgePx,
            isLoading = false,
            isAddingPages = adding,
            errorMessage = error,
        )
    }

    val uiState: StateFlow<ImportedPreviewUiState> = combine(
        baseUiState,
        isRecognizingText,
        recognizedText,
        ocrConfidence,
        ocrErrorMessage,
    ) { base, recognizing, text, confidence, ocrError ->
        base.copy(
            isRecognizingText = recognizing,
            recognizedText = text,
            ocrConfidence = confidence,
            ocrErrorMessage = ocrError,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ImportedPreviewUiState(isLoading = true),
    )

    fun selectPage(index: Int) {
        selectedPageIndex.value = index.coerceAtLeast(0)
        recognizedText.value = null
        ocrConfidence.value = null
        ocrErrorMessage.value = null
    }

    fun addPages(uris: List<Uri>, fallbackErrorMessage: String) {
        if (uris.isEmpty() || isAddingPages.value) return
        viewModelScope.launch {
            isAddingPages.value = true
            errorMessage.value = null
            val previousCount = uiState.value.project?.pages?.size ?: 0
            val result = projectRepository.addImagesToProject(projectId, uris)
            isAddingPages.value = false
            result.fold(
                onSuccess = { addedCount ->
                    if (addedCount > 0) {
                        selectedPageIndex.value = previousCount
                        recognizedText.value = null
                        ocrConfidence.value = null
                    }
                },
                onFailure = { err ->
                    errorMessage.value = err.localizedMessage?.takeIf { it.isNotBlank() }
                        ?: fallbackErrorMessage
                },
            )
        }
    }

    fun recognizeCurrentPage(filePath: String, fallbackErrorMessage: String) {
        if (isRecognizingText.value) return
        viewModelScope.launch {
            isRecognizingText.value = true
            recognizedText.value = null
            ocrConfidence.value = null
            ocrErrorMessage.value = null
            try {
                val bitmap = bitmapLoader.loadSampledBitmap(
                    filePath = filePath,
                    maxLongEdgePx = OCR_MAX_LONG_EDGE_PX,
                    preferLowMemoryConfig = false,
                ) ?: error("The selected page could not be decoded")
                val result = ocrEngine.recognize(bitmap)
                recognizedText.value = result.text
                ocrConfidence.value = result.confidence
            } catch (error: Exception) {
                ocrErrorMessage.value = error.localizedMessage
                    ?.takeIf { it.isNotBlank() }
                    ?: fallbackErrorMessage
            } finally {
                isRecognizingText.value = false
            }
        }
    }

    fun dismissError() {
        errorMessage.value = null
    }

    fun dismissOcrError() {
        ocrErrorMessage.value = null
    }

    companion object {
        private const val OCR_MAX_LONG_EDGE_PX = 2400

        fun factory(
            projectId: String,
            repository: ProjectRepository,
            preferencesStore: PreferencesStore,
            bitmapLoader: SampledBitmapLoader,
            ocrEngine: TesseractOcrEngine,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ImportedPreviewViewModel(
                    projectId,
                    repository,
                    preferencesStore,
                    bitmapLoader,
                    ocrEngine,
                ) as T
            }
        }
    }
}
