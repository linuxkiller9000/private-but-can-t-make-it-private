package com.bscan.app.processing.ocr

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Offline Arabic + English OCR backed by Tesseract 5.
 *
 * The standard Tesseract4Android artifact is deliberately used: it is single-threaded
 * and avoids adding unnecessary CPU contention on lower-powered devices.
 */
class TesseractOcrEngine(context: Context) {
    private val appContext = context.applicationContext
    private val engineMutex = Mutex()

    suspend fun recognize(
        bitmap: Bitmap,
        languages: String = DEFAULT_LANGUAGES,
    ): OcrRecognition = withContext(Dispatchers.IO) {
        engineMutex.withLock {
            val dataRoot = File(appContext.filesDir, "tesseract")
            val tessdataDir = File(dataRoot, "tessdata")
            if (!tessdataDir.exists() && !tessdataDir.mkdirs()) {
                throw IOException("Unable to create the OCR data directory")
            }

            val requestedLanguages = languages.split('+').filter { it.isNotBlank() }.distinct()
            if (requestedLanguages.isEmpty()) {
                throw IllegalArgumentException("At least one OCR language is required")
            }

            requestedLanguages.forEach { language ->
                installLanguageIfNeeded(language, tessdataDir)
            }

            val api = TessBaseAPI()
            try {
                if (!api.init(dataRoot.absolutePath, requestedLanguages.joinToString("+"))) {
                    throw IOException("Tesseract could not initialize the selected language data")
                }
                api.setImage(bitmap)
                val text = api.getUTF8Text().orEmpty().trim()
                OcrRecognition(
                    text = text,
                    confidence = api.meanConfidence().coerceIn(0, 100),
                    languages = requestedLanguages,
                )
            } finally {
                api.recycle()
            }
        }
    }

    private fun installLanguageIfNeeded(language: String, tessdataDir: File) {
        require(language.matches(Regex("[a-z]{3}"))) { "Unsupported OCR language code" }
        val target = File(tessdataDir, "$language.traineddata")
        if (target.isFile && target.length() > 0L) return

        if (target.exists()) target.delete()
        val temporary = File(tessdataDir, ".$language.traineddata.tmp")
        try {
            appContext.assets.open("$language.traineddata").use { input ->
                FileOutputStream(temporary).use { output ->
                    input.copyTo(output)
                    output.fd.sync()
                }
            }
            if (temporary.length() <= 0L) {
                throw IOException("The bundled $language OCR model is empty")
            }
            if (!temporary.renameTo(target)) {
                temporary.copyTo(target, overwrite = true)
                temporary.delete()
            }
        } catch (error: Exception) {
            temporary.delete()
            throw IOException(
                "The bundled $language OCR model could not be installed",
                error,
            )
        }
    }

    data class OcrRecognition(
        val text: String,
        val confidence: Int,
        val languages: List<String>,
    )

    companion object {
        const val DEFAULT_LANGUAGES = "ara+eng"
    }
}
