# BScan OCR Milestone 1 — Arabic + English

This is an **overlay update** for the existing `linuxkiller9000/bscan---` repository.
It is not a complete replacement of the repository.

## What this milestone adds

- Tesseract 5.5.1 through Tesseract4Android 4.9.0 (standard single-threaded build).
- Bundles the existing `models/tessdata_fast/ara.traineddata` and `eng.traineddata` files into the Android app from the repository's existing `models/tessdata_fast` directory.
- Copies those models once into app-private storage on first OCR use.
- Adds an offline Arabic + English OCR action to the imported-page preview.
- Samples the page to a maximum 2400 px long edge before OCR to limit memory use.
- Serializes OCR runs and releases the native Tesseract instance after each run.
- Updates English and Arabic UI strings and language availability labels.

## Apply

1. Make sure your existing repository is committed or backed up. Check `git status --short` first; don't overwrite local work you need.
2. Extract this ZIP **over the repository root**, preserving folder paths.
3. Run `bash APPLY_PATCHES.sh` from the repository root to update the Settings screen.
4. Open the Android project in `android/` and build with:

   `./gradlew :app:assembleDebug`

5. Install and test:
   - Import a clear Arabic document photo.
   - Open its preview.
   - Tap **Recognize text (Arabic + English)**.
   - Confirm text appears under Recognized text.
   - Repeat with an English page and a mixed-language page.

## Important

- No existing model files are included in this ZIP; the Gradle configuration uses the models already committed at `models/tessdata_fast/`.
- No internet permission is added to the Android manifest. Gradle needs internet only to fetch the Tesseract library during the build.
- This is source code, not a verified APK. It has not been compiled in an Android SDK environment here, so the first Gradle build is the validation gate.
- The unrelated Vite/React files at the repository root are untouched.
- If Gradle reports a build error, send the **first error block**, not the entire log. Do not delete Gradle caches or repository files.
