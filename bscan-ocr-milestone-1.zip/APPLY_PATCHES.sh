#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
git -C "$ROOT_DIR" apply --check "$ROOT_DIR/PATCHES/settings-screen.patch"
git -C "$ROOT_DIR" apply "$ROOT_DIR/PATCHES/settings-screen.patch"
echo "BScan OCR milestone 1 overlay patch applied."
